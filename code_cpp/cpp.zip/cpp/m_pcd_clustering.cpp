/*
 * m_pcd_clustering.cpp
 *
 *  Created on: Apr 24, 2015
 *      Author: phoenix
 */



/*
 * cluster_extraction.cpp
 *
 *  Created on: Apr 24, 2015
 *      Author: phoenix
 */

#include <pcl/ModelCoefficients.h>
#include <pcl/point_types.h>
#include <pcl/io/pcd_io.h>
#include <pcl/filters/extract_indices.h>
#include <pcl/filters/voxel_grid.h>
#include <pcl/features/normal_3d.h>
#include <pcl/kdtree/kdtree.h>
#include <pcl/sample_consensus/method_types.h>
#include <pcl/sample_consensus/model_types.h>
#include <pcl/segmentation/sac_segmentation.h>
#include <pcl/segmentation/extract_clusters.h>
#include <fstream>
#include <sstream>
#include <string>

using namespace std;

int main (int argc, char** argv){

  if (argc < 2){
     cout << "Usage: " << argv[0] << "<pcdFile>" << endl;
     cout << "or     " << argv[0] << "<pcdFile>" << "clusterTolerance" << endl;
     cout << "or     " << argv[0] << "<pcdFile>" << "clusterTolerance" << "txtId" << endl;
     exit(1);
  }

  if (argc > 4){
     cout << "Error: too many arguments" << endl;
     exit(1);
  }

  double clusterTolerance = 0.01;
  if (argc >= 3){
	  clusterTolerance = atof(argv[2]);
  }
  cout << "clusterTolerance is set to " << clusterTolerance << endl;
  
  int txtId = 1;
  if (argc == 4){
      txtId = atoi(argv[3]);
  }

  // Read in the cloud data
  pcl::PCDReader reader;
  pcl::PointCloud<pcl::PointXYZ>::Ptr cloud (new pcl::PointCloud<pcl::PointXYZ>);
  reader.read (argv[1], *cloud);
  int num_pts = cloud->points.size();
  cout << "loaded " << num_pts << " data points for image " << txtId << endl;

  // Creating the KdTree object for the search method of the extraction
  pcl::search::KdTree<pcl::PointXYZ>::Ptr tree (new pcl::search::KdTree<pcl::PointXYZ>);
  tree->setInputCloud (cloud);

  // filter out sparse distributed points
  std::vector<pcl::PointIndices> cluster_indices;
  pcl::EuclideanClusterExtraction<pcl::PointXYZ> ec;
  ec.setClusterTolerance (0.01); // 1cm
  ec.setMinClusterSize (30);
  ec.setMaxClusterSize (1000000);
  ec.setSearchMethod (tree);
  ec.setInputCloud (cloud);
  ec.extract(cluster_indices);

  pcl::PointCloud<pcl::PointXYZ>::Ptr my_cluster (new pcl::PointCloud<pcl::PointXYZ>);
  vector<int> my_index;
  for (std::vector<pcl::PointIndices>::const_iterator it = cluster_indices.begin ();
	                                                  it != cluster_indices.end (); ++it){

    for (std::vector<int>::const_iterator pit = it->indices.begin (); pit != it->indices.end (); ++pit){
      my_cluster->points.push_back (cloud->points[*pit]);
      my_index.push_back(*pit);
    }
  }

  // do Euclidean clustering again
  cluster_indices.clear();
  ec.setClusterTolerance (clusterTolerance); // unit meter
  ec.setMinClusterSize(200);
  ec.setInputCloud (my_cluster);
  ec.extract(cluster_indices);

  vector<int> my_index_1;
  vector<int> my_label;
  int l = 1;
  for (std::vector<pcl::PointIndices>::const_iterator it = cluster_indices.begin ();
		                                              it != cluster_indices.end (); ++it){
	int count = 0;
    for (std::vector<int>::const_iterator pit = it->indices.begin (); pit != it->indices.end (); ++pit){
      my_index_1.push_back (*pit);
      my_label.push_back(l);
      count++;
    }
    //cout << "cluster_" << l << ": " << count << " data points" << endl;
    l++;
  }
  cout << "there are " << (l-1) << " clusters in image " << txtId << endl;

  // save the clustering result to text file
  vector<int> v(num_pts, 0);

  for (unsigned int i = 0; i < my_index_1.size(); i++){
	  int id = my_index_1[i];
	  v[my_index[id]] = my_label[i];
  }

  ofstream outFile;
  ostringstream ostr;
  ostr << txtId;
  string filename = "clusters_"+ ostr.str() + ".txt";
  outFile.open(filename.c_str(), ofstream::out);
  if (outFile.is_open()){
	  for (int i = 0; i < num_pts; i++){
          outFile << v[i] << endl;
	  }
      outFile.close();
  }
  else{
	  cout << "Error opening file " <<endl;
  }

  return (0);
}





