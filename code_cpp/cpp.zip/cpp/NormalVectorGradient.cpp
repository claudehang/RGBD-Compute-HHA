// 20130605  Zhuo Deng Temple University
// calculate the gradient map based on the normal vector map
// [gradient,angle]=NormalVectorGradient(Mat_i) angle [0,pi]
// Mat_i is a wxhx3 matrix (double) 
#include "mex.h"
#include "CImg.h"
#include "objects.h"
#include "util.h"
#define PI 3.1515926
using namespace cimg_library;

void mexFunction(int nlhs, mxArray* plhs[], int nrhs, const mxArray* prhs[])
{
const int *dim=mxGetDimensions(prhs[0]);
const int w=dim[0]; const int h=dim[1]; const int d=dim[2];
const int n=w*h;

double* Mat_i=(double*)mxGetData(prhs[0]);
CImg<double> img_i(w,h,1,d,0);
for (int i=0; i<w; i++){
    for(int j=0;j<h; j++){
        for (int k=0; k<d;k++){
            img_i(i,j,0,k)=Mat_i[j*w+i+k*n];
        }
    }
}

CImg<double> img_o(w,h,1,1,0);
CImg<double> img_angle(w,h,1,1,0);
//cimg_forXY(img_o,x,y) img_o(x,y) = img_i(x,y,0,0);
//********************************************//

double Gx=0,Gy=0;
// sobel distance model
for (int i=1;i<(w-1); i++){
    for (int j=1; j<(h-1); j++){
        double temp1x=0,temp2x=0,temp3x=0,temp1y=0,temp2y=0,temp3y=0;
        for (int k=0;k<d;k++){
            temp1y +=img_i(i,j-1,0,k)*img_i(i,j+1,0,k);
            temp2y +=img_i(i-1,j-1,0,k)*img_i(i-1,j+1,0,k);
            temp3y +=img_i(i+1,j-1,0,k)*img_i(i+1,j+1,0,k);
            temp1x += img_i(i-1,j,0,k)*img_i(i+1,j,0,k);
            temp2x += img_i(i-1,j-1,0,k)*img_i(i+1,j-1,0,k);
            temp3x += img_i(i-1,j+1,0,k)*img_i(i+1,j+1,0,k);
        }
        Gx=2*sin(acos(temp1x))+sin(acos(temp2x))+sin(acos(temp3x));
        Gy=2*sin(acos(temp1y))+sin(acos(temp2y))+sin(acos(temp3y));
        img_o(i,j)=sqrt(pow(Gx,2.0)+pow(Gy,2.0));
        if (Gx==0)
            img_angle(i,j)=PI/2;
        else
            img_angle(i,j)=atan2(Gy,Gx);
    }
}
//****************************************//

int dim_1[2]={w,h};
plhs[0]=mxCreateNumericArray(2,dim_1,mxDOUBLE_CLASS,mxREAL);
plhs[1]=mxCreateNumericArray(2,dim_1,mxDOUBLE_CLASS,mxREAL);

double* gradient=(double*)mxGetData(plhs[0]);
double* angle=(double*)mxGetData(plhs[1]);

for (int i=0; i<w; i++){
    for (int j=0; j<h; j++){
	  gradient[j*w+i]=img_o(i,j);
      angle[j*w+i]=img_angle(i,j);
    }
}
}
