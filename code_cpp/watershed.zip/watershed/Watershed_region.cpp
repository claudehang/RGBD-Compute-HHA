// 20130604  Zhuo Deng Temple University
// Image Segmentation based on Watershed algorithm

// Matlab Function Format: [img_seg,seg_rgb]=Watershed_region(gradient_map,m_flag,marker,mask);
// Input:
    // gradient_map --- a gradient map based on grayscale image or other cues.
    // m_flag -- boolean variable. 1 for marker-based enabled ; 0 for disabled
    // marker -- marker matrix defined automatically or manually (marker points are assigned 255, the others are 0);
    // mask -- constraint on region (ROI consists of pixels with 255)
    // Matrix marker and mask should be in uint8 format.

// Output:
// img_seg --labeled segmentation (range from 0 to n);
// seg_rgb --visualized segmentaion (color image);

// Functionality:
// (1) Watershed_region(gradient_map,false);
// (2) Watershed_region(gradient_map,true,marker);
// (3) Watershed_region(gradient_map,true,marker,mask);
// (4) Watershed_region(gradient_map,false,[],mask);


#include "mex.h" //required 
#include "matrix.h"
#include "CImg.h" // related head files needed in c++
#include <iostream>
#include "util.h"
#include "objects.h"
#include "watershed.h"
using namespace cimg_library;
 


// template <class T,class T1>
// void CImgMat2Arr3D(T* output,CImg<T1>* label){
//    int w=label->dimx(); int h=label->dimy();
//    int n=w*h;
//    for (int i=0;i<w;i++){
//       for (int j=0;j<h;j++){
//               //output[j*w+i]=(*label)(i,j);
//           for (int d=0;d<3;d++){
//               output[j*w+i+d*n]=(*label)(i,j,0,d);
//           }
//       }     
//    }
// }


void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
// nlhs: the number of arguments for output
// plhs[]: the list of output arguments
// nrhs: the number of arguments for input
// prhs[]: the list of input arguments
{

   if (nrhs<2)
       mexErrMsgTxt("There should be at least 2 arguments");
   if (nrhs>4)
       mexErrMsgTxt("The number of argument exceeds the maximum.");
   
   //data structure initialization for prhs[0], plhs[0] and plhs[1]
   const int D=mxGetNumberOfDimensions(prhs[0]);
   if (D!=2)
       mexErrMsgTxt("The gradient map should be in 2 Dimension.");
   const int *dim=mxGetDimensions(prhs[0]); //get size of gradient map   
   const int w=dim[0]; const int h=dim[1]; const int n=w*h;
   double * gradient_i=(double*)mxGetData(prhs[0]);
   CImg<double> gradient_map(w,h,1,1,0); // data structure in CImg Library
   for (int i=0;i<w;i++){
        for (int j=0;j<h;j++){
            gradient_map(i,j)=gradient_i[j*w+i];
        } 
   }
   CImg<double> gradient=gradient_map.get_normalize(10,255);
   CImg<unsigned char> gradient_norm(w,h,1,1,0);
   cimg_forXY(gradient,x,y) gradient_norm(x,y) = (unsigned char)gradient(x,y);
   

   
   int dim_3[3]={w,h,3};
   plhs[0]=mxCreateNumericArray(2,dim,mxINT32_CLASS,mxREAL);
   plhs[1]=mxCreateNumericArray(3,dim_3,mxUINT8_CLASS,mxREAL); // generate 3 dimensional matrix
   int * img_o1=(int *)mxGetData(plhs[0]);
   unsigned char * img_o2=(unsigned char *)mxGetData(plhs[1]);
   CImg<signed int>    result(w,h,1,1,-1);
   CImg<unsigned char> result_ok1(w,h,1,3,0);
   CImg<unsigned char> marker_neg(w,h,1,1,0);
   CImg<unsigned char> marker(w,h,1,1,0);
   
   if (nrhs==2){ //Watershed_region(gradient_map,0);
       
       const int *dim_1=mxGetDimensions(prhs[1]);
       if (dim_1[0]!=1 || dim_1[1]!=1)
           mexErrMsgTxt("The second argument should be 1 by 1 matrix.");
       
       int* arg2=(int*)mxGetData(prhs[1]);
       const int mflag=arg2[0];
       
       if (mflag==1)
           mexErrMsgTxt("Change the value of second argument to 0 or add one more arguments.");
       
       WatershedSegmentation(gradient_norm, &result, 0, 0);
       
       result_ok1 = colorizeLabelImage( result,true );
       for (int i=0;i<w;i++){
          for (int j=0;j<h;j++){
                 img_o1[j*w+i]=result(i,j);
                 for (int d=0;d<3;d++){
                     img_o2[j*w+i+d*n]=result_ok1(i,j,0,d);
                 }
          }     
       }
       mexPrintf("OK!\n");  
   }
   else if (nrhs==3){ //Watershed_region(gradient_map,1,markers)
       
       const int *dim_1=mxGetDimensions(prhs[1]);
       if (dim_1[0]!=1 || dim_1[1]!=1)
           mexErrMsgTxt("The second argument should be 1 by 1 matrix.");
       
       int* arg2=(int*)mxGetData(prhs[1]);
       const int mflag=arg2[0];
       
       if (mflag==0)
           mexErrMsgTxt("Change the value of second argument to 1.");
       
       const int* dim_2=mxGetDimensions(prhs[2]);
       if (dim_2[0]!=w ||dim_2[1]!=h) {
           mexErrMsgTxt("the size (w*h) of marker should be the same as the image!");}
       
       unsigned char * img_mark=(unsigned char *)mxGetData(prhs[2]);
       for (int i=0;i<w;i++){
          for (int j=0;j<h;j++){
              marker(i,j)=img_mark[j*w+i];
          }
       }
       cimg_forXY(marker,x,y) marker_neg(x,y) = 255-marker(x,y); // Invert marker images (lines should to be black)
       gradient_norm = gradient_norm & marker_neg; 
       
       WatershedSegmentation(gradient_norm, &result, mflag, 0);
       
       result_ok1 = colorizeLabelImage( result,true );
       for (int i=0;i<w;i++){
          for (int j=0;j<h;j++){
                 img_o1[j*w+i]=result(i,j);
                 for (int d=0;d<3;d++){
                     img_o2[j*w+i+d*n]=result_ok1(i,j,0,d);
                 }
          }     
       } 
      // CImgMat2Arr3D<unsigned char,unsigned char>(img_o2,&result_ok1);
       mexPrintf("OK!\n"); 
       
   }
   else{//Watershed_region(gradient_map,1,marker,mask);or Watershed_region(gradient_map,0,[],mask);
       const int *dim_1=mxGetDimensions(prhs[1]);
       if (dim_1[0]!=1 || dim_1[1]!=1)
           mexErrMsgTxt("The second argument should be 1 by 1 matrix.");
       
       int* arg2=(int*)mxGetData(prhs[1]);
       const int mflag=arg2[0];
  
       //initialize mask
       unsigned char *img_mask=(unsigned char *)mxGetData(prhs[3]);
       CImg<unsigned char> mask(w,h,1,1,0);
       for (int i=0;i<w;i++){
          for (int j=0;j<h;j++){
            mask(i,j)=img_mask[j*w+i];
          }
       }
       CImg<unsigned char> mask_neg(w,h,1,1,0);
       cimg_forXY(mask,x,y) mask_neg(x,y) = 255-mask(x,y);
       
       if (mflag==1){
           const int *dim_2=mxGetDimensions(prhs[2]);
           if (dim_2[0]!=w ||dim_2[1]!=h) {
               mexErrMsgTxt("the size (w*h) of marker should be the same as the image!");}
           
           unsigned char * img_mark=(unsigned char *)mxGetData(prhs[2]);
           for (int i=0;i<w;i++){
              for (int j=0;j<h;j++){
                  marker(i,j)=img_mark[j*w+i];
              }
           }
           marker=marker & mask;
           cimg_forXY(marker,x,y) marker_neg(x,y) = 255-marker(x,y);
           gradient_norm = gradient_norm & marker_neg;
           WatershedSegmentation(gradient_norm, &result,mask_neg, 1, 0);
           result_ok1 = colorizeLabelImage( result,true );
           for (int i=0;i<w;i++){
              for (int j=0;j<h;j++){
                     img_o1[j*w+i]=result(i,j);
                     for (int d=0;d<3;d++){
                         img_o2[j*w+i+d*n]=result_ok1(i,j,0,d);
                     }
              }     
           }
           mexPrintf("OK!\n"); 
       }
       else{
           const int *dim_2=mxGetDimensions(prhs[2]);
           if(dim_2[0]!=0 || dim_2[1]!=0)
               mexErrMsgTxt("The third arguments should be []");
           
           WatershedSegmentation(gradient_norm, &result,mask_neg, 0, 0);
           result_ok1 = colorizeLabelImage( result,true );
           for (int i=0;i<w;i++){
              for (int j=0;j<h;j++){
                     img_o1[j*w+i]=result(i,j);
                     for (int d=0;d<3;d++){
                         img_o2[j*w+i+d*n]=result_ok1(i,j,0,d);
                     }
              }     
           }
           mexPrintf("OK!\n"); 
       }  
   }
    
//    if (mxGetNumberOfDimensions(prhs[0])>2)
//    {
//        //********************initialize input and output************************//
//        const int *dim = mxGetDimensions(prhs[0]); //get dimensions of a color image
//        const int *dim_1 = mxGetDimensions(prhs[1]);  
//        const int w=dim[0];
//        const int h=dim[1];
//        if (dim_1[0]!=w ||dim_1[1]!=h) {
//            mexErrMsgTxt("the size (w*h) of marker should be the same as the image!");}
//        const int n=w*h;
//        unsigned char * img_i=(unsigned char *)mxGetData(prhs[0]);
//        unsigned char * img_mark=(unsigned char *)mxGetData(prhs[1]);
//        //point to the first element of the image data.The type of pointer could be changed
//            
//        int dim_2[2]={w,h};
//        plhs[0]=mxCreateNumericArray(2,dim_2,mxUINT8_CLASS,mxREAL);
//        plhs[1]=mxCreateNumericArray(3,dim,mxUINT8_CLASS,mxREAL); // generate 3 dimensional matrix
//        unsigned char * img_o1=(unsigned char *)mxGetData(plhs[0]);
//        unsigned char * img_o2=(unsigned char *)mxGetData(plhs[1]);
//        
//        //*******************************************************************//
//             
//        CImg<unsigned char> image_rgb(w,h,1,3,0); // image data structure in CImg Library
//        for (int i=0;i<w;i++){ //copy img_i to image_rgb
//           for (int j=0;j<h;j++){
//               for (int d=0;d<3;d++){        
//                  image_rgb(i,j,0,d)=img_i[j*w+i+d*n]; //access to the data in color image structure
//               }
//           }     
//        }
//        CImg<unsigned char> image_gray = image_rgb.get_resize(-100,-100,-100,1);
//        CImg<unsigned char> blur_img = image_gray.get_blur(2);
//        CImg<unsigned char> gradient = gradient_cimg(blur_img, 2);
//        CImg<unsigned char> gradient_norm = gradient.get_normalize(10,255);
//        CImg<unsigned char> marker(w,h,1,1,0); //create an image "marker" with size [Dx, Dy] and assign 0 to pixels
//        for (int i=0;i<w;i++){
//           for (int j=0;j<h;j++){
//               marker(i,j)=img_mark[j*w+i];
//           }
//        }
//        
//         CImg<unsigned char> marker_neg(w,h,1,1,0);
//         CImg<unsigned char> gradmarker(w,h,1,1,0);
//         CImg<signed int>    result(w,h,1,1,-1);
//         CImg<unsigned char> result_ok1(w,h,1,3,0);
//         
//         if (nrhs>3){
//            unsigned char *img_mask=(unsigned char *)mxGetData(prhs[2]);
//            CImg<unsigned char> mask(w,h,1,1,0);
//            for (int i=0;i<w;i++){
//               for (int j=0;j<h;j++){
//                 mask(i,j)=img_mask[j*w+i];
//               }
//            }
//            CImg<unsigned char> mask_neg(w,h,1,1,0);
//            cimg_forXY(mask,x,y) mask_neg(x,y) = 255-mask(x,y);
//             marker=marker & mask;
//             cimg_forXY(marker,x,y) marker_neg(x,y) = 255-marker(x,y);
//             gradmarker = gradient_norm & marker_neg;
//             WatershedSegmentation(gradmarker, &result,mask_neg, 1, 0);
//         }
//         else{
//             cimg_forXY(marker,x,y) marker_neg(x,y) = 255-marker(x,y); // Invert marker images (lines should to be black)
//             gradmarker = gradient_norm & marker_neg; //make maker points be zeros and other points remain the same (& is bitwise and here)
//             WatershedSegmentation(gradmarker, &result, 1, 0);
//         }
//         
//         result_ok1 = colorizeLabelImage( result,true );
//        
// 
//        for (int i=0;i<w;i++){
//           for (int j=0;j<h;j++){
//                  img_o1[j*w+i]=result(i,j);
//                  for (int d=0;d<3;d++){
//                      img_o2[j*w+i+d*n]=result_ok1(i,j,0,d);
//                  }
//           }     
//        }
//        mexPrintf("OK!\n");
//    }
//    else //grayimage
//    {
//       const int row_img=mxGetM(prhs[0]);
//       const int col_img=mxGetN(prhs[0]);
//       unsigned char * img=(unsigned char *)mxGetPr(prhs[0]);
// 
//       CImg<unsigned char> image_test(row_img,col_img,1,1,0); 
// 
//         for (int i=0;i<row_img;i++)
//         {
//           for (int j=0;j<col_img;j++)
//           {
//              image_test(i,j)=img[j*row_img+i]; //access data in grayimage  
//           }     
//         }
//       CImg<unsigned char> blur_img = image_test.get_blur(2);
//       int dim[2]={row_img, col_img};
//       plhs[0]=mxCreateNumericArray(2,dim,mxUINT8_CLASS,mxREAL);
//       unsigned char* output=(unsigned char*)mxGetData(plhs[0]);
// 
//       for (int i=0;i<row_img;i++)
//         {
//           for (int j=0;j<col_img;j++)
//           {
//              output[j*row_img+i]=blur_img(i,j); //access data in grayimage  
//           }     
//         }
//        mexPrintf("OK!\n");
//    }
  
}






















